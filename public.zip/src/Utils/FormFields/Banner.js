export const BannerFields = [
    // {
    //     name: 'order',
    //     label: 'View Order',
    //     placeholder: 'Banner order ',
    //     required: true,
    //     message: 'please input your View Order',
    //     type: 'text',
    //     // accept: 'image'
    // },
    {
        name: 'image',
        label: 'Banner Image',
        // placeholder: 'Health',
        required: false,
        message: 'please Select your Category Image',
        type: 'file',
        accept: 'image'
    },
]