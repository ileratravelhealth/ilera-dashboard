export const ForgetPasswordFields = [
    {
        name: 'phone',
        label: 'phone number with country code:',
        placeholder: '+8801566026301',
        required: true,
        message: 'please input your phone number',
        type: 'text',
    },
]